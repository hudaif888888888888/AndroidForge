# CodeQuest — Complete Web Development Path

A mobile-first, lightweight coding-learning PWA prototype.

## Courses included
- HTML: document structure, text, links/images, lists, forms, semantic HTML
- CSS: selectors, cascade, typography/spacing, box model, Flexbox, Grid, responsive design
- JavaScript: console, variables, data types, operators, strings, conditions, loops, functions, arrays, objects, DOM, events
- Web skills: browser devtools, debugging, HTTP/APIs, accessibility
- Tools: Git, GitHub and publishing
- React: components, props and state
- Projects: portfolio and mini-app publishing

## Open / install
- Open `index.html` in a modern browser to try the app.
- For installable offline PWA behavior, host this folder on HTTPS, open it in Chrome on Android, then use Add to Home screen / Install app.
- Progress, XP and focus time are stored locally in this browser.

## Features
- 30 interactive lessons with quick-check quizzes
- Daily 60-minute focus timer (study longer if you want)
- JavaScript playground and HTML/CSS preview
- XP, completion tracking and local progress
- Mozilla MDN and JavaScript.info learning references
- PWA manifest, service worker and custom app icon

## Notes
This is a web app/PWA package, not a compiled or signed Android APK. An APK needs an Android wrapper/build environment. The JavaScript playground is for learning snippets, not secure execution of untrusted code; do not paste code from strangers. The timer tracks time while the app is open and active.
